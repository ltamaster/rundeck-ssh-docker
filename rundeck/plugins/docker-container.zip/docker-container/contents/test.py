#!/usr/bin/env python -u
import argparse
import logging
import shlex
import sys
import os
import json
from subprocess import Popen, PIPE

log_level = 'DEBUG'

logging.basicConfig(
    stream=sys.stderr,
    level=getattr(logging, log_level),
    format='%(levelname)s: %(name)s: %(message)s'
)
log = logging.getLogger('container-model-source')


ps_command=["docker","ps","--format",'"{{.ID}}"']

ps_command.append("--filter")
ps_command.append("name=rundeck")


ps = Popen(
    ' '.join(ps_command),
    shell=True,
    stdout=PIPE,
    stderr=PIPE,
    bufsize=1,
    universal_newlines=True
)
exitcode = ps.wait()

if exitcode != 0:
    log.error('Failure from docker ps command (exitcode: %s)' % str(exitcode))
    sys.exit(exitcode)

containers = ps.stdout.readlines()
log.debug('Processing %d containers ...' % len(containers))

for container in containers:
    log.debug('Inspecting container: %s' % container)

